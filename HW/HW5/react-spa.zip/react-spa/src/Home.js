import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>HELLO</h2>
        <p>We stuff we learn in this site is, </p>
 
        <p>A summary of what you obtain from the pdf in reference to REACT concepts - Easy learning</p>
        <p>something that you enjoy doing within this class- in class exercises</p>
      </div>
    );
  }
}
 
export default Home;