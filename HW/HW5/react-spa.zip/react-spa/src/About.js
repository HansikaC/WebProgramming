import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>About Me</h2>
        <p>This is all about me ;p
        </p>
      </div>
    );
  }
}
 
export default Contact;