import React, { Component } from "react";
 
class Stuff extends Component {
  render() {
    return (
      <div>
        <h2>The Good STUFF</h2>
        <p>A summary of what you obtain from the pdf in reference to REACT concepts</p>
        <ol>
          <li>Stuff</li>
          <li>Other stuff</li>
          <li>Some other stuff</li>
        </ol>
      </div>
    );
  }
}
 
export default Stuff;
